class WelcomeController < ApplicationController
  def credits
  end
end
