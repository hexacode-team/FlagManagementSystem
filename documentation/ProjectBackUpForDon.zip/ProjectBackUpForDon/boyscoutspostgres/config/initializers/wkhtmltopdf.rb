#Rails.application.config.action_controller.asset_host = "http://localhost"
