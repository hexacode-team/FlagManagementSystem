class Latest < ActiveRecord::Migration
  def change
  end
end
