require 'test_helper'

class SubscriptionPaymentsHelperTest < ActionView::TestCase
end
