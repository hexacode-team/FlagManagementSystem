require 'test_helper'

class RoutesHelperTest < ActionView::TestCase
end
